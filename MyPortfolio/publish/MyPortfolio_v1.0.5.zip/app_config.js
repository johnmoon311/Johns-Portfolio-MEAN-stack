var config = {};

config.email = {
	username: "johnmoon1993@gmail.com",
	password: "asdfasdf123"
};

module.exports = config;