#include "ghost.h"

Ghost::Ghost(char face, int ghostSkill):SpriteClass(face), ghostIntellegence(ghostSkill)
{

}
