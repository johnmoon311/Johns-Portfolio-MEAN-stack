#include "pacman.h"

PacMan::PacMan(char face):SpriteClass(face)
{
}

