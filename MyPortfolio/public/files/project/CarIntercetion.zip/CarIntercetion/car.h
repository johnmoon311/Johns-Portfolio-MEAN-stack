#ifndef car_h
#define car_h

const int CAR_LENGTH=16;
const int CAR_WIDTH=10;

class Car : public sf::RectangleShape
{
    public:
    Car(){};
};

#endif
