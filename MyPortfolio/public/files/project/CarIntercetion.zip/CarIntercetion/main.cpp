#include <SFML/Graphics.hpp>
#include "App.h"



int main()
{
    App myapp(3);
    myapp.Run();
}
